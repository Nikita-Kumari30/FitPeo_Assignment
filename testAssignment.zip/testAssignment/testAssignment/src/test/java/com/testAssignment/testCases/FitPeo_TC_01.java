package com.testAssignment.testCases;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FitPeo_TC_01 {

	WebDriver driver;
	public List<String> items =new ArrayList<String>();

	
	@Test(priority = 1)
	public void navigateToFitPeoHomePage() throws InterruptedException {
		try {
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
			driver.manage().window().maximize();
			Thread.sleep(1000);
			driver.navigate().to("https://www.fitpeo.com/");
			Thread.sleep(1000);
			System.out.println("Navigated to FitPeo homepage");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(priority = 2)
	public void navigateToRevenueCalculatorPage() throws InterruptedException {
		try {
			WebElement revenueCalculatorLink =driver.findElement(By.xpath("//div[text()='Revenue Calculator']"));
			revenueCalculatorLink.click();
			Thread.sleep(1000);
			System.out.println("Navigated to Revenue Calculator page");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(priority = 3)
	public void scrollToSliderSection() throws InterruptedException {
		try {
			Actions action= new Actions(driver);
			WebElement sliderElement=driver.findElement(By.xpath("//h4[text()='Medicare Eligible Patients']/../div/span[1]"));
			action.moveToElement(sliderElement);
			Thread.sleep(1000);
			System.out.println("Verified Slider Section");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(priority = 4)
	public void adjustSlider() throws InterruptedException {
		try {
			WebElement slider = driver
					.findElement(By.xpath("//h4[text()='Medicare Eligible Patients']/../div/span[1]/span/input"));
			Actions actions = new Actions(driver);
			int sliderWidth =slider.getSize().getWidth(); 
			int currentValue =Integer.parseInt(slider.getAttribute("aria-valuenow"));
			int targetValue = 820; 
			int min =Integer.parseInt(slider.getAttribute("aria-valuemin"));
			int max =Integer.parseInt(slider.getAttribute("aria-valuemax"));
			//double step =Double.parseDouble(slider.getAttribute("step"));
			//double totalSteps =(max - min) / step; 
			double valuePerPixel = (double) (max - min) /sliderWidth; 
			int xOffset = (int) ((targetValue - currentValue) /valuePerPixel); 
			actions.clickAndHold(slider).moveByOffset(xOffset,0).release().perform();
			Thread.sleep(3000);
			System.out.println("Adjusted Slider");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(priority = 5)
	public void updateTextFieldFunctionality() throws InterruptedException {
		try {
			WebElement inputTextElement=driver.findElement(By.xpath("//input[@type='number']"));
			inputTextElement.click();
			inputTextElement.clear();
			inputTextElement.sendKeys("560");
			System.out.println("Updated Text Field");
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test(priority = 6)
	public void verifySliderValue() {
		try {
			WebElement element=driver.findElement(By.xpath("//h4[text()='Medicare Eligible Patients']/../div/span[1]/span/input"));
			String sliderValue=element.getAttribute("aria-valuenow");
			System.out.println("Verified Slider value");
			Assert.assertEquals(sliderValue, "560","value not updated");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	 
	
	  @Test(priority = 7)
	  public void selectCptCode() throws InterruptedException {
		  try {
			  items.add("CPT-99453"); 
			  items.add("CPT-99453"); 
			  items.add("CPT-99454");
			  items.add("CPT-99474");
			  Actions actions=new Actions(driver);
			  for(int i=0;i<items.size();i++) { 
				  String xpath = "//p[text()='TEXT']/../label/span/input";
				  xpath=xpath.replace("TEXT", items.get(i));
				  WebElement element=driver.findElement(By.xpath(xpath));
			  actions.moveToElement(element); 
			  Thread.sleep(2000); 
			  element.click();
			  System.out.println("Checked "+items.get(i)); }
			  System.out.println("Selected CPT codes"); 
		} catch (Exception e) {
			e.printStackTrace();
		}
	  }
	 
	@Test(priority = 8)
	public void calculateRecurringReimbursement() {
		try {
			Actions actions= new Actions(driver);
			actions.moveToElement(driver.findElement(By.xpath("//p[text()='Total Recurring Reimbursement for all Patients Per Month']//parent::div//p[2]//text()[2])")));
			Thread.sleep(2000);
			WebElement recurringReimbursementElement=driver.findElement(By.xpath("//p[text()='Total Recurring Reimbursement for all Patients Per Month']//parent::div//p[2]//text()[2])"));
			String reimbursement = recurringReimbursementElement.getText();
			int sum=0;
			for(int i=0;i<items.size();i++) {
				String xpath = "//p[text()='Text']/../label/span[2]";
				WebElement element=driver.findElement(By.xpath(xpath.replace("Text", items.get(i))));
				String text =element.getText();
				sum=sum+(Integer.parseInt(text));
			}
			System.out.println("Calculated Recurring Reimbursement");
			Assert.assertEquals(String.valueOf(sum*560), reimbursement,"value is not matched");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Test(priority = 9)
	public void verifyHeaderDisplay() {
		try {
			WebElement element=driver.findElement(By.xpath("//p[text()='Total Recurring Reimbursement for all Patients Per Month:']/p/text()[2]"));
			String text=element.getText();
			System.out.println("Verified Recurring Reimbursement");
			Assert.assertEquals(text, "110700","Improper value is displaying");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
}
